create procedure rb()
  begin
    rollback;
  end;

